module.exports = (sequelize, DataTypes) => {
    const Persona = sequelize.define('persona', {
        nombre: {
            type: DataTypes.STRING,
            allowNull: false
        },
        foto: {
            type: DataTypes.STRING,
            allowNull: true
        }
    });
    return Persona;
};
