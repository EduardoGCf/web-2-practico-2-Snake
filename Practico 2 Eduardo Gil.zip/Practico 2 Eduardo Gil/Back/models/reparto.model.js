module.exports = (sequelize, DataTypes) => {
    const Reparto = sequelize.define('reparto', {
        rol: {
            type: DataTypes.ENUM('actor', 'director', 'ambos'),
            allowNull: false
        }
    });
    return Reparto;
};
