const Sequelize = require('sequelize');
const dbConfig = require('../config/db.config');

// Conexión a la base de datos
const sequelize = new Sequelize(dbConfig.DB, dbConfig.USER, dbConfig.PASSWORD, {
    host: dbConfig.HOST,
    dialect: 'mysql',
    port: dbConfig.PORT,
    logging: false,
});

const db = {};

// Modelos
db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.peliculas = require('./pelicula.model')(sequelize, Sequelize);
db.personas = require('./persona.model')(sequelize, Sequelize);
db.reparto = require('./reparto.model')(sequelize, Sequelize);
db.usuarios = require('./usuario.model')(sequelize, Sequelize);

// Relación muchos a muchos entre Peliculas y Personas (a través de Reparto)
db.peliculas.belongsToMany(db.personas, { through: db.reparto });
db.personas.belongsToMany(db.peliculas, { through: db.reparto });

// Sincroniza la base de datos
db.sequelize.sync()
    .then(() => {
        console.log("Base de datos sincronizada.");
    })
    .catch((err) => {
        console.log("Error al sincronizar la base de datos: ", err);
    });

module.exports = db;
