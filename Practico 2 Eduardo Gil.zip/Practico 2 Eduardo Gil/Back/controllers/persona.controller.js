const db = require('../models');
const Persona = db.personas;

// Crear una nueva persona (actor/director)
exports.crearPersona = async (req, res) => {
    const { nombre, foto } = req.body;

    try {
        const nuevaPersona = await Persona.create({ nombre, foto });
        res.status(201).json(nuevaPersona);
    } catch (error) {
        res.status(500).json({ message: error.message || "Ocurrió un error al crear la persona." });
    }
};

// Obtener todas las personas (actores/directores)
exports.obtenerPersonas = async (req, res) => {
    try {
        const personas = await Persona.findAll();
        res.status(200).json(personas);
    } catch (error) {
        res.status(500).json({ message: error.message || "Ocurrió un error al obtener las personas." });
    }
};

// Obtener una persona por su ID
exports.obtenerPersonaPorId = async (req, res) => {
    const id = req.params.id;

    try {
        const persona = await Persona.findByPk(id);
        if (!persona) {
            return res.status(404).json({ message: "Persona no encontrada." });
        }
        res.status(200).json(persona);
    } catch (error) {
        res.status(500).json({ message: error.message || "Ocurrió un error al obtener la persona." });
    }
};

// Actualizar una persona por su ID
exports.actualizarPersona = async (req, res) => {
    const id = req.params.id;
    const { nombre, foto } = req.body;

    try {
        const persona = await Persona.findByPk(id);
        if (!persona) {
            return res.status(404).json({ message: "Persona no encontrada." });
        }

        persona.nombre = nombre || persona.nombre;
        persona.foto = foto || persona.foto;

        await persona.save();
        res.status(200).json({ message: "Persona actualizada con éxito.", persona });
    } catch (error) {
        res.status(500).json({ message: error.message || "Ocurrió un error al actualizar la persona." });
    }
};

// Eliminar una persona por su ID
exports.eliminarPersona = async (req, res) => {
    const id = req.params.id;

    try {
        const persona = await Persona.findByPk(id);
        if (!persona) {
            return res.status(404).json({ message: "Persona no encontrada." });
        }

        await persona.destroy();
        res.status(200).json({ message: "Persona eliminada con éxito." });
    } catch (error) {
        res.status(500).json({ message: error.message || "Ocurrió un error al eliminar la persona." });
    }
};
