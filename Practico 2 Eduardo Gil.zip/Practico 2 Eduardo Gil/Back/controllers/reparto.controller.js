const db = require('../models');
const Pelicula = db.peliculas;
const Persona = db.personas;
const Reparto = db.reparto;

// Asociar una persona (actor o director) a una película
exports.asociarPersona = async (req, res) => {
    const { peliculaId, personaId, rol } = req.body; // 'rol' puede ser 'actor' o 'director'

    try {
        const pelicula = await Pelicula.findByPk(peliculaId);
        const persona = await Persona.findByPk(personaId);

        if (!pelicula || !persona) {
            return res.status(404).json({ message: "Película o persona no encontrada." });
        }

        // Asociar la persona a la película en el rol correspondiente
        await pelicula.addPersona(persona, { through: { rol } });
        res.status(200).json({ message: `Persona asociada como ${rol} a la película.` });
    } catch (error) {
        res.status(500).json({ message: error.message || "Ocurrió un error al asociar la persona a la película." });
    }
};

// Eliminar una asociación (persona de reparto) de una película
exports.eliminarPersona = async (req, res) => {
    const { peliculaId, personaId } = req.body;

    try {
        const pelicula = await Pelicula.findByPk(peliculaId);
        const persona = await Persona.findByPk(personaId);

        if (!pelicula || !persona) {
            return res.status(404).json({ message: "Película o persona no encontrada." });
        }

        // Eliminar la asociación entre la persona y la película
        await pelicula.removePersona(persona);
        res.status(200).json({ message: "Persona eliminada del reparto de la película." });
    } catch (error) {
        res.status(500).json({ message: error.message || "Ocurrió un error al eliminar la persona del reparto." });
    }
};

// Obtener el reparto completo de una película
exports.obtenerReparto = async (req, res) => {
    const { peliculaId } = req.params;

    try {
        const pelicula = await Pelicula.findByPk(peliculaId, {
            include: [{
                model: Persona,
                through: {
                    attributes: ['rol']
                }
            }]
        });

        if (!pelicula) {
            return res.status(404).json({ message: "Película no encontrada." });
        }

        res.status(200).json(pelicula.personas); // Retorna el reparto (personas) de la película
    } catch (error) {
        res.status(500).json({ message: error.message || "Ocurrió un error al obtener el reparto de la película." });
    }
};


// Eliminar todo el reparto de una película
exports.eliminarTodoReparto = async (req, res) => {
    const { peliculaId } = req.body;

    try {
        const pelicula = await Pelicula.findByPk(peliculaId, {
            include: [Persona]
        });

        if (!pelicula) {
            return res.status(404).json({ message: "Película no encontrada." });
        }

        // Eliminar todas las asociaciones (reparto) de la película
        await pelicula.setPersonas([]);  // Esto elimina todas las relaciones con personas

        res.status(200).json({ message: "Todo el reparto ha sido eliminado de la película." });
    } catch (error) {
        res.status(500).json({ message: error.message || "Ocurrió un error al eliminar todo el reparto." });
    }
};
