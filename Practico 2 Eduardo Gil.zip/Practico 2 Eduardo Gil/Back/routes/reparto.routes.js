const express = require('express');
const router = express.Router();
const repartoController = require('../controllers/reparto.controller');
const { verificarAdministrador } = require('../middleware/auth.middleware');

// Asociar una persona (actor o director) a una película
router.post('/asociar', repartoController.asociarPersona);

// Eliminar una persona del reparto de una película
router.post('/eliminar', repartoController.eliminarPersona);

// Eliminar todo el reparto de una película
router.post('/eliminarTodo', repartoController.eliminarTodoReparto);

// Obtener el reparto completo de una película
router.get('/:peliculaId', repartoController.obtenerReparto);

module.exports = router;
