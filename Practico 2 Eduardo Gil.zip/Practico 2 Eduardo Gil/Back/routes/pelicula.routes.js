const express = require('express');
const router = express.Router();
const peliculaController = require('../controllers/pelicula.controller');
const { verificarAdministrador } = require('../middleware/auth.middleware');

// Crear una nueva película
router.post('/', peliculaController.crearPelicula);

// Obtener todas las películas
router.get('/', peliculaController.obtenerPeliculas);

// Obtener una película por su ID
router.get('/:id', peliculaController.obtenerPeliculaPorId);

// Actualizar una película por su ID
router.put('/:id', peliculaController.actualizarPelicula);

// Eliminar una película por su ID
router.delete('/:id', peliculaController.eliminarPelicula);

module.exports = router;
