const express = require('express');
const router = express.Router();
const personaController = require('../controllers/persona.controller');
const { verificarAdministrador } = require('../middleware/auth.middleware');

// Crear una nueva persona (actor/director)
router.post('/', personaController.crearPersona);

// Obtener todas las personas (actores/directores)
router.get('/', personaController.obtenerPersonas);

// Obtener una persona por su ID
router.get('/:id', personaController.obtenerPersonaPorId);

// Actualizar una persona por su ID
router.put('/:id', personaController.actualizarPersona);

// Eliminar una persona por su ID
router.delete('/:id', personaController.eliminarPersona);

module.exports = router;
